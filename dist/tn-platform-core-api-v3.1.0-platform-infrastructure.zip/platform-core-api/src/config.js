import { z } from "zod";

const schema = z.object({
  PORT: z.coerce.number().int().positive().default(3000),
  API_KEY: z.string().min(24),
  ALLOWED_GROUPS: z.string().default("thecaverns"),
  BROWSER_HEADLESS: z.string().default("true"),
  REQUEST_TIMEOUT_MS: z.coerce.number().int().min(10000).max(120000).default(45000),
  CACHE_TTL_SECONDS: z.coerce.number().int().min(0).default(900),
  MAX_EVENTS_PER_SYNC: z.coerce.number().int().min(1).max(500).default(150),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error("Invalid environment configuration", parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const config = {
  ...parsed.data,
  allowedGroups: parsed.data.ALLOWED_GROUPS.split(",").map(v => v.trim()).filter(Boolean),
  browserHeadless: parsed.data.BROWSER_HEADLESS !== "false",
};
